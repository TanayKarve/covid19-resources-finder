<script>
  export let large = true;
</script>

<div>
  <h2>Tips</h2>
  <ol>
    {#if large}
      <li><strong>Do NOT make advanced payments unless you are 100% sure about their authenticity</strong></li>
      <li>Check for replies under the tweets</li>
    {/if}
    <li>
      Make sure search results are sorted by "Latest"
      <br />
      <img src="sort-click-here.jpg" alt="" />
    </li>
  </ol>
</div>