import App from "./nApp.svelte";

const app = new App({
  target: document.body
});

export default app;
