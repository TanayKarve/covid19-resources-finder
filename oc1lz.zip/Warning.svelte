<p>
	<p class="lead">
		This is a simple tool to help you search for valuable covid-19 resources online.</p>
	<p class="my-2">
		<li>Do NOT make advanced payments unless you are 100% sure about their authenticity</li>
		<li>Check for replies under the tweets</li>
	</p>


	<!-- <script>
  export let message;
</script>

<p>
  🎉 {message} 🍾
</p> -->